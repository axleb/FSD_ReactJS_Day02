const express= require('express');
const port = 8000;
const api = express();
const data = require('./../Data/data.json');
//
api.use(express.json());
api.use(express.urlencoded({extended:false}));
//
api.get('/getemployees', function(request, response){
  response.send(data);
})
api.get('/', function(request, response){
  response.send('you are on the root route');
});
api.post('/addnewemployee', function(request, response){
  let empName = request.body.empName;
  let empPass = request.body.empPass;
  console.log(`POST success, you sent ${empName} and ${empPass}, thanks!`);
  response.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
});
//
api.listen(port, function(){
	console.log("Listening " + port);
});
