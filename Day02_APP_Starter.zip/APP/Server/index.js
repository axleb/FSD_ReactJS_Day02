const express= require('express');
const port = 8000;
const app = express();
const data = require('./../Data/data.json');
//
app.use(express.json());
app.use(express.urlencoded({extended:false}));
//
app.get('/getemployees', function(request, response){
  response.send(data);
})
app.get('/', function(request, response){
  response.send('you are on the root route');
});
app.post('/addnewemployee', function(request, response){
  let empName = request.body.empName;
  let empPass = request.body.empPass;
  console.log(`POST success, you sent ${empName} and ${empPass}, thanks!`);
  response.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
});
//
app.listen(port, function(){
	console.log("Listening " + port);
});
