const Employee = require('./../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
exports.getemployees = function(req, res){
  Employee.find({}, function(err, results){
    if (err)
      res.end(err);
    res.json(results);
  });
};
exports.addnewemployee = function(req, res){
  const Emp = new Employee();
  Emp.empName = req.body.empName;
  Emp.empPass = req.body.empPass;
  Emp.save({}, function(err){
    if (err)
     res.end(err);
    res.end(`Created ${Emp.empName}`);
  });
};
//
exports.addnewweight = function(req, res){
  let empName = req.body.empName;
  let empWeight = parseInt(req.body.empWeight);
  Employee.updateOne(
    {empName: empName},
    {$addToSet:
      { employeeWeights :
        {
          empWeight:empWeight
        }
      }
    },
    {upsert : true },
    function(err, doc) {
      if(err) {
        return console.log(err);
      } else {
        return res.send("done");
      }
    }
  );
};
