const controller = require('./../controllers/controller');
module.exports = function(api){
  api.route('/').get(controller.getdefault);
  api.route('/getemployees').get(controller.getemployees);
  api.route('/addnewemployee').post(controller.addnewemployee);
};
//
