const mongoose = require('mongoose');
mongoose.connect(
  'mongodb://localhost:27017/Weights',
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  }
);
//
const empSchema = new mongoose.Schema({
    empName: String,
    empPass: String,
    createdOn: {type: Date, default: Date.now }
  }, {
    collection:'employeeWeights'
  }
);
//
module.exports = mongoose.model('Employee', empSchema);
