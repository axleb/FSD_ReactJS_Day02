const express= require('express');
const port = 8000;
const api = express();
const routes = require('./../routes/routes');
const router = express.Router();
//
api.use(express.json());
api.use(express.urlencoded({extended:false}));
routes(api);
api.use('/', router);
//
api.listen(port, function(){
	console.log("Listening " + port);
});
