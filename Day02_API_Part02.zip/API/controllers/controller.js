const data = require('./../Data/data.json');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
exports.getemployees = function(req, res){
  res.send(data);
};
exports.addnewemployee = function(req, res){
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  res.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
};
