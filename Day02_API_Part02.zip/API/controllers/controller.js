exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
exports.getemployees = function(req, res){
  res.send('coming soon.');
};
exports.addnewemployee = function(req, res){
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  res.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
};
